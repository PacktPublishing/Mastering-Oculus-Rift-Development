﻿using UnityEngine;
using System.Collections;

public class DynamicWall : MonoBehaviour 
{
	[SerializeField]
	private GameObject wallSection;
    public bool isRaised = true;

    public IEnumerator MoveSectionUp()
    {
        while (wallSection.transform.localPosition.y < 4.5f)
        {
            wallSection.transform.Translate(Vector3.up * 0.5f);
            yield return null;
        }

        isRaised = true;
    }

	public IEnumerator MoveSectionDown()
	{
		while(wallSection.transform.localPosition.y > -5f)
		{
			wallSection.transform.Translate(Vector3.down * 0.5f);
			yield return null;
		}

        isRaised = false;
	}

	// Use this for initialization
	void Start () 
	{
	
	}
	
	// Update is called once per frame
	void Update () 
	{

	}
}
